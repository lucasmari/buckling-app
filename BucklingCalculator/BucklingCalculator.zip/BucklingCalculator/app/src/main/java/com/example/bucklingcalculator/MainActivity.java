package com.example.bucklingcalculator;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    // End Condition variable
    private double effectiveLengthFactor;

    // Material properties variables
    private double yieldStrength;
    private double elasticModulus;

    // Cross Section properties variables
    private double area;
    private double centroidalDistance;
    private double gyrationRadius;
    private double inertiaMoment;

    // EditTexts variables
    private double length;
    private double load;
    private double eccentricity;

    // Results variables
    private double criticalStress;
    private double criticalForce;

    // Material/Cross Section ArrayLists
    private ArrayList[] materials = new ArrayList[3];
    private ArrayList[] crossSections = new ArrayList[5];

    private CheckBox checkBox;
    private EditText editText3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Soft keyboard configuration
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        // Components declaration
        ConstraintLayout layout = findViewById(R.id.layout);
        ConstraintLayout layout2 = findViewById(R.id.layout2);
        ImageView columnImageView = findViewById(R.id.columnImageView);
        Spinner spinner1 = findViewById(R.id.spinner1);
        Spinner spinner2 = findViewById(R.id.spinner2);
        Spinner spinner3 = findViewById(R.id.spinner3);
        EditText editText1 = findViewById(R.id.editText1);
        EditText editText2 = findViewById(R.id.editText2);
        checkBox = findViewById(R.id.checkBox);
        editText3 = findViewById(R.id.editText3);
        Button calculateButton = findViewById(R.id.calculateButton);
        Button clearButton = findViewById(R.id.clearButton);
        TextView resultsTextView = findViewById(R.id.resultsTextView);


        ConstraintSet constraintSet1 = new ConstraintSet();
        constraintSet1.clone(this, R.layout.activity_main);
        ConstraintSet constraintSet2 = new ConstraintSet();
        constraintSet2.clone(this, R.layout.activity_main_2);

        // Materials ArrayLists initialization
        materials[0] = new ArrayList();
        materials[0].add(getResources().getString(R.string.material_1));
        materials[0].add(getResources().getString(R.string.material_2));
        materials[1] = new ArrayList();
        materials[1].add(getResources().getString(R.string.yield_strength_1));
        materials[1].add(getResources().getString(R.string.yield_strength_2));
        materials[2] = new ArrayList();
        materials[2].add(getResources().getString(R.string.elastic_modulus_1));
        materials[2].add(getResources().getString(R.string.elastic_modulus_2));

        // Cross Sections ArrayLists initialization
        crossSections[0] = new ArrayList();
        crossSections[0].add(getResources().getString(R.string.cross_section_1));
        crossSections[0].add(getResources().getString(R.string.cross_section_2));
        crossSections[1] = new ArrayList();
        crossSections[1].add(51.61E-4);
        crossSections[1].add(90E9);
        crossSections[2] = new ArrayList();
        crossSections[2].add(0.02540);
        crossSections[2].add(90E9);
        crossSections[3] = new ArrayList();
        crossSections[3].add(0.01466);
        crossSections[3].add(90E9);
        crossSections[4] = new ArrayList();
        crossSections[4].add(111E-5);
        crossSections[4].add(90E9);


        // Animations
        Animation fade_out = AnimationUtils.loadAnimation(getApplication(), R.anim.fade_out);
        Animation fade_in = AnimationUtils.loadAnimation(getApplication(), R.anim.fade_in);

        // Spinner 1 adapter/listener
        setSpinnerAdapter1(spinner1);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 1:
                        effectiveLengthFactor = 0.9;
                        columnImageView.startAnimation(fade_out);
                        columnImageView.setImageResource(R.mipmap.img_column_fixed_fixed);
                        columnImageView.startAnimation(fade_in);
                        break;
                    case 2:
                        effectiveLengthFactor = 0.9;
                        columnImageView.startAnimation(fade_out);
                        columnImageView.setImageResource(R.mipmap.img_column_fixed_pinned);
                        columnImageView.startAnimation(fade_in);
                        break;
                    case 3:
                        effectiveLengthFactor = 2.1;
                        columnImageView.startAnimation(fade_out);
                        columnImageView.setImageResource(R.mipmap.img_column_fixed_free);
                        columnImageView.startAnimation(fade_in);
                        break;
                    case 0:
                    default:
                        effectiveLengthFactor = 1;
                        columnImageView.startAnimation(fade_out);
                        columnImageView.setImageResource(R.mipmap.img_column_pinned_pinned);
                        columnImageView.startAnimation(fade_in);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Spinner 2 adapter/listener
        setSpinnerAdapter2(spinner2);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                yieldStrength = Double.valueOf(materials[1].get(position).toString());
                elasticModulus = Double.valueOf(materials[2].get(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Spinner 3 adapter/listener
        setSpinnerAdapter3(spinner3);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                area = Double.valueOf(crossSections[1].get(position).toString());
                centroidalDistance = Double.valueOf(crossSections[2].get(position).toString());
                gyrationRadius = Double.valueOf(crossSections[3].get(position).toString());
                inertiaMoment = Double.valueOf(crossSections[4].get(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // Calculate button listener
        calculateButton.setOnClickListener(v -> {
            View view = this.getCurrentFocus();
            if (view != null) {
                InputMethodManager imm =
                        (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }

            if (validInputs(editText1, editText2, editText3)) {
                length = Double.valueOf(editText1.getText().toString());
                load = Double.valueOf(editText2.getText().toString());
                eccentricity = Double.valueOf(editText3.getText().toString());

                setResults(resultsTextView);

                TransitionManager.beginDelayedTransition(layout);
                constraintSet2.applyTo(layout);
            }
        });

        // Clear button listener
        clearButton.setOnClickListener(v -> {
            TransitionManager.beginDelayedTransition(layout);
            constraintSet1.applyTo(layout);
            resultsTextView.setText(getString(R.string.results_tv));
            editText1.setText(getString(R.string.value_et));
            editText1.clearFocus();
            editText2.setText(getString(R.string.value_et));
            editText2.clearFocus();
            checkBox.setChecked(false);
            editText3.setText(getString(R.string.value_et));
            editText3.clearFocus();
        });

        // Checkbox listener
        checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (checkBox.isChecked())
                editText3.setEnabled(true);
            else
                editText3.setEnabled(false);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.settings:
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent)   ;
                return true;
            case R.id.share:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // End Condition Spinner
    public void setSpinnerAdapter1(Spinner spinner1) {
        List<String> spinnerArray = new ArrayList<>();
        spinnerArray.add(getResources().getString(R.string.end_condition_1));
        spinnerArray.add(getResources().getString(R.string.end_condition_2));
        spinnerArray.add(getResources().getString(R.string.end_condition_3));
        spinnerArray.add(getResources().getString(R.string.end_condition_4));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, R.layout.item_spinner, spinnerArray);
        spinner1.setAdapter(adapter);
    }

    // Material Spinner
    public void setSpinnerAdapter2(Spinner spinner2) {
        List<String> spinnerArray = new ArrayList<>();
        spinnerArray.add(getResources().getString(R.string.material_1));
        spinnerArray.add(getResources().getString(R.string.material_2));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, R.layout.item_spinner, spinnerArray);
        spinner2.setAdapter(adapter);
    }

    // Cross Section Spinner
    public void setSpinnerAdapter3(Spinner spinner3) {
        List<String> spinnerArray = new ArrayList<>();
        spinnerArray.add(getResources().getString(R.string.cross_section_1));
        spinnerArray.add(getResources().getString(R.string.cross_section_2));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, R.layout.item_spinner, spinnerArray);
        spinner3.setAdapter(adapter);
    }

    public boolean validInputs(EditText editText1, EditText editText2, EditText editText3) {
        if (editText1.getText().toString().equals("0") || editText1.getText().toString().equals(
                "")) {
            Toast.makeText(getApplicationContext(), "Length not set!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (editText2.getText().toString().equals("0") || editText2.getText().toString().equals(
                "")) {
            Toast.makeText(getApplicationContext(), "Load not set!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (editText3.getText().toString().equals("")) {
            Toast.makeText(getApplicationContext(), "Eccentricity not set!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    public double calculateCriticalStress() {
        if (checkBox.isChecked() && !editText3.getText().toString().equals("0"))
            criticalStress =
                    (load / area) * (1 + ((eccentricity * centroidalDistance) / Math.pow(gyrationRadius, 2)) * Math.acos(((effectiveLengthFactor * length) / (2 * gyrationRadius)) * Math.sqrt(load / (area * elasticModulus))));
        else
            criticalStress =
                    yieldStrength - (Math.pow((yieldStrength * effectiveLengthFactor * length) / (2 * Math.PI * gyrationRadius), 2)) * (1 / elasticModulus);

        return criticalStress;
    }

    public double calculateCriticalForce() {
        double area = 51.61E-4;

        criticalForce = criticalStress * area;

        return criticalForce;
    }

    public double calculateFactorOfSafety() {
        return criticalForce / load;
    }

    public void setResults(TextView resultsTextView) {
        resultsTextView.setText(getString(R.string.results_tv));
        resultsTextView.append("\n\nCritical Stress: " + convert(calculateCriticalStress(), 2) +
                "Pa");
        resultsTextView.append("\nCritical Force: " + convert(calculateCriticalForce(), 2) + "N");
        resultsTextView.append("\nFactor of Safety: " + convert(calculateFactorOfSafety(), 2));
        resultsTextView.append("\n\nGraphics");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
        resultsTextView.append("\n.");
    }

    public static String convert(double val, int dp) {
        final String[] PREFIX_ARRAY = {"f", "p", "n", "µ", "m", "", "k", "M", "G", "T"};

        // If the value is zero, then simply return 0 with the correct number of dp
        if (val == 0) return String.format("%." + dp + "f", 0.0);

        // If the value is negative, make it positive so the log10 works
        double posVal = (val < 0) ? -val : val;
        double log10 = Math.log10(posVal);

        // Determine how many orders of 3 magnitudes the value is
        int count = (int) Math.floor(log10 / 3);

        // Calculate the index of the prefix symbol
        int index = count + 5;

        // Scale the value into the range 1<=val<1000
        val /= Math.pow(10, count * 3);

        if (index >= 0 && index < PREFIX_ARRAY.length) {
            // If a prefix exists use it to create the correct string
            return String.format("%." + dp + "f%s", val, PREFIX_ARRAY[index]);
        } else {
            // If no prefix exists just make a string of the form 000e000
            return String.format("%." + dp + "fe%d", val, count * 3);
        }
    }
}
